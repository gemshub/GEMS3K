GEMS3K commit: 54b5f819ba83589daa9cd9aa0a9ff699adb28b1d (branch develop_optima, 2026-11-03)

# GEMS3K restructuring plan — summary

**What this is.** A plan to make GEMS3K easier to change and then faster, in two strictly separated stages. No
code was changed, committed or pushed. The detail is in files 00–09; `NOTES.md` holds the reading notes.

## Main findings

1. **The code works, but much of its state is hidden.** About 25 thread-local flags carry decisions between the
   retry layers of `GEM_run`. Some activity models keep process-wide caches keyed only on T and density, so two
   phases or two threads can get each other's values. Two environment variables change results.
2. **Some contracts exist only by discipline.** A new `BASE_PARAM` field needs 8 edits in GEMS3K
   (the brief's 7 sites, with the count 164 typed twice by hand) and up to 5 more in GEMSGUI. `copyMULTIData`
   copies fields by memory layout. Its counts are already off by one, so `FitVar[1..4]` are not copied.
3. **There are real bugs to fix later.** `TNodeArray` counts Optima "OK" codes as errors. Its warm-mode results
   depend on the thread count. dn/db is taken from the first Optima attempt, not from the accepted answer. The IPM
   reader has an out-of-bounds loop. These fixes change answers, so they belong to Stage B, after an owner decision.
4. **Where the time goes** (21 public projects, measured). Small systems take 0.1–3 ms per call in any mode.
   Cold Optima runs 25–35× slower than the GEMS3K IPM solver on mid-size systems. Failing warm calls cost
   1 000–13 000× a normal call. In Optima runs, a quarter of the work is bookkeeping around the activity models
   (all phases are recomputed for every finite-difference column). The model formulas themselves are cheap.
5. **All 14 traps of the brief were found in the code.** Each has its file, function and line (09).

## Target structure (04)

Eleven modules in folders and CMake targets: core, data, io, thermo, models, numerics, kernel (GEMS3K IPM solver),
optima (adapter), run (retry layers), node, nodearray, plus diag (traces). The installed library and headers
keep their names. A `RunContext` object replaces the thread-local flags. `BASE_PARAM` gets one declaration
file. The diagnostics stay byte for byte. Three libraries sit around the solver:
- **ThermoFun** gives all standard-state T-P properties. GEMS3K's own grid interpolation is first made
  switchable, then removed after a full comparison shows that ThermoFun reproduces it (10). GEMSGUI's own T-P
  methods follow in their own track.
- **ThermoSol** (new) holds the phase models: activity, mixing and excess properties. It starts from `TActivity`,
  where GEMS links the models today, and follows the ThermoFun v2 principles: named records with units, a model
  registry, and recomputing only what changed (11).
- **ThermoKin** (new) holds the kinetics, starting from `TKinetics` (11).

`12-performance-techniques.md` lists the speed techniques: vectorisation, GPU batches, reduced systems,
computing only what changes, memoisation and on-demand learning.

## Part II — systems without GEMSGUI (13, separate work)

- **Separate from the restructuring.** Part I (Stages A and B) never waits for it; it keeps Part II in mind through
  eight design rules (04 §9, A-rule 6).
- **A C++ builder** (like Reaktoro) picks elements, species, phases and phase models from ThermoFun v2 and ThermoSol
  records. `system.yaml` is the same object saved, and Python gets it through xgems.
- **Easy by default, every option settable:** a database, a bulk composition, T and P are enough. Profiles add the
  defaults of a field (cement, hydrothermal, …), and anything can be set by hand. Every automatic choice is saved in
  a resolved file.
- **User-friendly files:** `system.yaml` plus a ThermoFun v2 dataset becomes GEMSGUI's export; DCH/IPM/DBR become an
  internal legacy format; results get a named results file with units.

## Order of work

- **Stage A (05, behaviour kept, 25–35 small pull requests).** Steps in order:
  - A0 baseline freeze on the owner's machine;
  - A1 build cleanup;
  - A2 contract tests;
  - A3 `BASE_PARAM` from one declaration;
  - A4–A5 settings access and getters;
  - A6 `RunContext`;
  - A7–A9 workspace, statics and environment variables;
  - A10 files into modules and splitting the 4 400-line Optima function;
  - A11 warm-start state;
  - A12 de-duplication;
  - A13 diagnostics component;
  - A14 tests and docs;
  - A15 one source for T-P data (`ThermoSource`), A16 one phase-property code (`TActivity`), A17 model registry.

  Every step must reproduce the STD and RAW freezes row for row, including `# dec`.
- **Stage B (06, scored like a solver change).** Steps in order:
  - B0 nudge baseline;
  - B1 bug fixes;
  - B2 thread safety;
  - B3 failure cost;
  - B4 activity-call scope;
  - B5 analytic Hessian blocks;
  - B6 pre-solve;
  - B7 linear algebra;
  - B8 line search;
  - B9 allocations;
  - B10–B12 floating-point policy, parallel node batches and libm;
  - B13 ThermoFun comparison and switch, B14 grid removal, B15–B17 ThermoSol and ThermoKin as libraries.
- **Part II, track S (13), separate from Stages A and B:** S0 profiles and automatic rules, S1 definition object and
  YAML, S2 builder, S3 converter from legacy exports and corpus round trip, S4 Python, S5 direct start, S6 ThermoSol
  records, S7 results file, S8 GEMSGUI export switch.
- **Extensions (07).** dn/db at the accepted answer comes first. No GPU work starts until a CPU batch test shows
  that most nodes stay on the common path.

## Five biggest risks (08)

1. **The freeze runs only on the owner's machine.** gems-benchmark became accessible: CTest passes 92 of 96, and
   the CI check reproduces 114 of 132 recorded rows (the rest differ because of the machine, not the code). But
   the freeze driver is in no repository, so the owner must run the baseline (A0) or publish the driver.
2. **Moving hot code can change the floating-point results** through inlining. Each step checks the freeze and
   the instruction counts.
3. **A hidden flag may be read on an unexpected path** while the thread-locals are replaced. This is handled by
   per-flag lists, debug mirrors and the DECIDE golden test.
4. **GEMSGUI depends on internals:** it subclasses `TMultiBase`, reads `MULTI` and stores `BASE_PARAM` by
   position. Those parts stay fixed, with compile-time checks.
5. **The activity call is not repeatable** (it keeps a history), and freezes differ between CPU types. So Stage A
   never changes the number of calls, and all freezes use one machine class.

Open questions with assumed defaults: 08 §3 (35 items).
